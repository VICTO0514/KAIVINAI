package com.victo.kaivinai.data.dto;

import com.victo.kaivinai.data.dto.enums.UserStatus;

public class ServiceCategory {

        private Long       id;
        private String     categoryName;
        private String     description;
        private UserStatus status;
        private Long       createdAt;

        public ServiceCategory(Long id,String categoryName,String description,UserStatus status,Long createdAt) {
            this.id           = id;
            this.categoryName = categoryName;
            this.description  = description;
            this.status       = status;
            this.createdAt    = createdAt;
        }

        public Long   getId()           { return id; }
        public String getCategoryName() { return categoryName; }
        public String getDescription()  { return description; }
        public UserStatus getStatus()   { return status; }
        public Long   getCreatedAt()    { return createdAt; }

        public void setId(Long id)               { this.id = id; }
        public void setCategoryName(String name) { this.categoryName = name; }
        public void setDescription(String desc)  { this.description = desc; }
        public void setStatus(UserStatus status) { this.status = status; }
        public void setCreatedAt(Long createdAt) { this.createdAt = createdAt; }
}
