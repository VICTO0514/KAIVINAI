package com.victo.kaivinai.data.dto;

public class Review {

    private Long    id;
    private Long    bookingId;
    private Long    customerId;
    private Long    providerId;
    private Integer starRating;
    private String  comment;
    private Long    createdAt;

    public Review(Long id, Long bookingId, Long customerId, Long providerId, Integer starRating,
                  String comment, Long createdAt) {
        this.id         = id;
        this.bookingId  = bookingId;
        this.customerId = customerId;
        this.providerId = providerId;
        this.starRating = starRating;
        this.comment    = comment;
        this.createdAt  = createdAt;
    }

    public Long    getId()         { return id; }
    public Long    getBookingId()  { return bookingId; }
    public Long    getCustomerId() { return customerId; }
    public Long    getProviderId() { return providerId; }
    public Integer getStarRating() { return starRating; }
    public String  getComment()    { return comment; }
    public Long    getCreatedAt()  { return createdAt; }

    public void setId(Long id)               { this.id = id; }
    public void setBookingId(Long bookingId) { this.bookingId = bookingId; }
    public void setCustomerId(Long cid)      { this.customerId = cid; }
    public void setProviderId(Long pid)      { this.providerId = pid; }
    public void setStarRating(Integer star)  { this.starRating = star; }
    public void setComment(String comment)   { this.comment = comment; }
    public void setCreatedAt(Long createdAt) { this.createdAt = createdAt; }
}
