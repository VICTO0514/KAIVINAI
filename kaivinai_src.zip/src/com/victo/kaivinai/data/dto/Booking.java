package com.victo.kaivinai.data.dto;

import com.victo.kaivinai.data.dto.enums.BookingStatus;

public class Booking {

    public enum Priority {
        Urgent, Normal
    }

    private Long          id;
    private String        bookingId;
    private Long          customerId;
    private Long          providerId;
    private Long          categoryId;
    private String        problemDescription;
    private String        address;
    private String        area;
    private String        city;
    private String        pincode;
    private Priority      priority;
    private BookingStatus status;
    private Long          scheduledTime;
    private Long          createdTime;
    private Long          updatedTime;
    private Long          completedTime;
    private String        remarks;

    public Booking(Long id,String bookingId,Long customerId,Long providerId,Long categoryId,String problemDescription,
                   String address,String area,String city,String pincode,Priority priority,BookingStatus status,
                   Long scheduledTime,Long createdTime,Long updatedTime,Long completedTime,String remarks) {
        this.id                 = id;
        this.bookingId          = bookingId;
        this.customerId         = customerId;
        this.providerId         = providerId;
        this.categoryId         = categoryId;
        this.problemDescription = problemDescription;
        this.address            = address;
        this.area               = area;
        this.city               = city;
        this.pincode            = pincode;
        this.priority           = priority;
        this.status             = status;
        this.scheduledTime      = scheduledTime;
        this.createdTime        = createdTime;
        this.updatedTime        = updatedTime;
        this.completedTime      = completedTime;
        this.remarks            = remarks;
    }

    public Long          getId()                 { return id; }
    public String        getBookingId()          { return bookingId; }
    public Long          getCustomerId()         { return customerId; }
    public Long          getProviderId()         { return providerId; }
    public Long          getCategoryId()         { return categoryId; }
    public String        getProblemDescription() { return problemDescription; }
    public String        getAddress()            { return address; }
    public String        getArea()               { return area; }
    public String        getCity()               { return city; }
    public String        getPincode()            { return pincode; }
    public Priority      getPriority()           { return priority; }
    public BookingStatus getStatus()             { return status; }
    public Long          getScheduledTime()      { return scheduledTime; }
    public Long          getCreatedTime()        { return createdTime; }
    public Long          getUpdatedTime()        { return updatedTime; }
    public Long          getCompletedTime()      { return completedTime; }
    public String        getRemarks()            { return remarks; }

    public void setId(Long id)                          { this.id = id; }
    public void setBookingId(String bookingId)          { this.bookingId = bookingId; }
    public void setCustomerId(Long customerId)          { this.customerId = customerId; }
    public void setProviderId(Long providerId)          { this.providerId = providerId; }
    public void setCategoryId(Long categoryId)          { this.categoryId = categoryId; }
    public void setProblemDescription(String pd)        { this.problemDescription = pd; }
    public void setAddress(String address)              { this.address = address; }
    public void setArea(String area)                    { this.area = area; }
    public void setCity(String city)                    { this.city = city; }
    public void setPincode(String pincode)              { this.pincode = pincode; }
    public void setPriority(Priority priority)          { this.priority = priority; }
    public void setStatus(BookingStatus status)         { this.status = status; }
    public void setScheduledTime(Long scheduledTime)    { this.scheduledTime = scheduledTime; }
    public void setCreatedTime(Long createdTime)        { this.createdTime = createdTime; }
    public void setUpdatedTime(Long updatedTime)        { this.updatedTime = updatedTime; }
    public void setCompletedTime(Long completedTime)    { this.completedTime = completedTime; }
    public void setRemarks(String remarks)              { this.remarks = remarks; }
}
