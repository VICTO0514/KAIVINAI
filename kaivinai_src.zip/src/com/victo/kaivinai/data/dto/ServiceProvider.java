package com.victo.kaivinai.data.dto;

import com.victo.kaivinai.data.dto.enums.UserStatus;

public class ServiceProvider {

    public enum ProviderAvailability {
        Available, Busy, Offline
    }

    public enum VerificationStatus {
        Pending, Verified, Rejected
    }

    private Long                 id;
    private String               providerId;
    private String               name;
    private String               email;
    private String               password;
    private String               mobileNo;
    private String               address;
    private String               area;
    private String               city;
    private String               pincode;
    private Long                 categoryId;
    private String               skills;
    private Integer              experienceYears;
    private Double               avgRating;
    private Integer              totalReviews;
    private ProviderAvailability availability;
    private VerificationStatus   verificationStatus;
    private UserStatus           status;
    private Long                 createdAt;

    public ServiceProvider(Long id, String providerId, String name, String email, String password, String mobileNo,  String address, String area, String city,
                           String pincode, Long categoryId, String skills, Integer experienceYears, Double avgRating,
                           Integer totalReviews, ProviderAvailability availability, VerificationStatus verificationStatus,
                           UserStatus status, Long createdAt) {
        this.id                 = id;
        this.providerId         = providerId;
        this.name               = name;
        this.email              = email;
        this.password           = password;
        this.mobileNo           = mobileNo;
        this.address            = address;
        this.area               = area;
        this.city               = city;
        this.pincode            = pincode;
        this.categoryId         = categoryId;
        this.skills             = skills;
        this.experienceYears    = experienceYears;
        this.avgRating          = avgRating;
        this.totalReviews       = totalReviews;
        this.availability       = availability;
        this.verificationStatus = verificationStatus;
        this.status             = status;
        this.createdAt          = createdAt;
    }

    public Long getId()                   { return id; }
    public String getProviderId()         { return providerId; }
    public String getName()               { return name; }
    public String getEmail()              { return email; }
    public String getPassword()           { return password; }
    public String getMobileNo()           { return mobileNo; }
    public String getAddress()            { return address; }
    public String getArea()               { return area; }
    public String getCity()               { return city; }
    public String getPincode()            { return pincode; }
    public Long   getCategoryId()         { return categoryId; }
    public String getSkills()             { return skills; }
    public Integer getExperienceYears()   { return experienceYears; }
    public Double  getAvgRating()         { return avgRating; }
    public Integer getTotalReviews()      { return totalReviews; }
    public ProviderAvailability getAvailability()     { return availability; }
    public VerificationStatus getVerificationStatus() { return verificationStatus; }
    public UserStatus getStatus()         { return status; }
    public Long getCreatedAt()            { return createdAt; }

    public void setId(Long id)                                    { this.id = id; }
    public void setProviderId(String providerId)                  { this.providerId = providerId; }
    public void setName(String name)                              { this.name = name; }
    public void setEmail(String email)                            { this.email = email; }
    public void setPassword(String password)                      { this.password = password; }
    public void setMobileNo(String mobileNo)                      { this.mobileNo = mobileNo; }
    public void setAddress(String address)                        { this.address = address; }
    public void setArea(String area)                              { this.area = area; }
    public void setCity(String city)                              { this.city = city; }
    public void setPincode(String pincode)                        { this.pincode = pincode; }
    public void setCategoryId(Long categoryId)                    { this.categoryId = categoryId; }
    public void setSkills(String skills)                          { this.skills = skills; }
    public void setExperienceYears(Integer experienceYears)       { this.experienceYears = experienceYears; }
    public void setAvgRating(Double avgRating)                    { this.avgRating = avgRating; }
    public void setTotalReviews(Integer totalReviews)             { this.totalReviews = totalReviews; }
    public void setAvailability(ProviderAvailability availability){ this.availability = availability; }
    public void setVerificationStatus(VerificationStatus vs)      { this.verificationStatus = vs; }
    public void setStatus(UserStatus status)                      { this.status = status; }
    public void setCreatedAt(Long createdAt)                      { this.createdAt = createdAt; }
}
