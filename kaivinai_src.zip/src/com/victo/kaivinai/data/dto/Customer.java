package com.victo.kaivinai.data.dto;

import com.victo.kaivinai.data.dto.enums.UserStatus;

public class Customer {

        private Long       id;
        private String     customerId;
        private String     name;
        private String     email;
        private String     password;
        private String     mobileNo;
        private String     address;
        private String     area;
        private String     city;
        private String     pincode;
        private UserStatus status;
        private Long       createdAt;

        public Customer(Long id, String customerId, String name,String email, String password, String mobileNo,
                        String address, String area, String city, String pincode, UserStatus status, Long createdAt)
        {
            this.id         = id;
            this.customerId = customerId;
            this.name       = name;
            this.email      = email;
            this.password   = password;
            this.mobileNo   = mobileNo;
            this.address    = address;
            this.area       = area;
            this.city       = city;
            this.pincode    = pincode;
            this.status     = status;
            this.createdAt  = createdAt;
        }

        public Long   getId()         { return id; }
        public String getCustomerId() { return customerId; }
        public String getName()       { return name; }
        public String getEmail()      { return email; }
        public String getPassword()   { return password; }
        public String getMobileNo()   { return mobileNo; }
        public String getAddress()    { return address; }
        public String getArea()       { return area; }
        public String getCity()       { return city; }
        public String getPincode()    { return pincode; }
        public UserStatus getStatus() { return status; }
        public Long getCreatedAt()    { return createdAt; }

        public void setId(Long id)               { this.id = id; }
        public void setCustomerId(String cid)    { this.customerId = cid; }
        public void setName(String name)         { this.name = name; }
        public void setEmail(String email)       { this.email = email; }
        public void setPassword(String password) { this.password = password; }
        public void setMobileNo(String mobileNo) { this.mobileNo = mobileNo; }
        public void setAddress(String address)   { this.address = address; }
        public void setArea(String area)         { this.area = area; }
        public void setCity(String city)         { this.city = city; }
        public void setPincode(String pincode)   { this.pincode = pincode; }
        public void setStatus(UserStatus status) { this.status = status; }
        public void setCreatedAt(Long createdAt) { this.createdAt = createdAt; }
}
