package com.victo.kaivinai.data.dto.enums;

public enum UserStatus {
    Active, Inactive
}
