package com.victo.kaivinai.data.dto.enums;

public enum BookingStatus {
    Requested, Accepted, Rejected, OnTheWay, InProgress, Completed, Cancelled

}
