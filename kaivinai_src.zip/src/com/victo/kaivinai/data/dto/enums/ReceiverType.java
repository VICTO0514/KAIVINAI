package com.victo.kaivinai.data.dto.enums;

public enum ReceiverType {
    Customer,Provider,Admin
}
