package com.victo.kaivinai.data.dto;

import com.victo.kaivinai.data.dto.enums.BookingStatus;
import com.victo.kaivinai.data.dto.enums.ReceiverType;

public class BookingStatusHistory {

    private Long          id;
    private Long          bookingId;
    private Long          changedBy;
    private ReceiverType  changedByType;
    private BookingStatus oldStatus;
    private BookingStatus newStatus;
    private String        remarks;
    private Long          changedTime;

    public BookingStatusHistory(Long id, Long bookingId, Long changedBy,
                                ReceiverType changedByType,
                                BookingStatus oldStatus,
                                BookingStatus newStatus,
                                String remarks, Long changedTime) {
        this.id            = id;
        this.bookingId     = bookingId;
        this.changedBy     = changedBy;
        this.changedByType = changedByType;
        this.oldStatus     = oldStatus;
        this.newStatus     = newStatus;
        this.remarks       = remarks;
        this.changedTime   = changedTime;
    }

    public Long getId()                     { return id; }
    public Long getBookingId()              { return bookingId; }
    public Long getChangedBy()              { return changedBy; }
    public ReceiverType  getChangedByType() { return changedByType; }
    public BookingStatus getOldStatus()     { return oldStatus; }
    public BookingStatus getNewStatus()     { return newStatus; }
    public String        getRemarks()       { return remarks; }
    public Long          getChangedTime()   { return changedTime; }

    public void setId(Long id)                       { this.id = id; }
    public void setBookingId(Long bookingId)         { this.bookingId = bookingId; }
    public void setChangedBy(Long changedBy)         { this.changedBy = changedBy; }
    public void setChangedByType(ReceiverType cbt)   { this.changedByType = cbt; }
    public void setOldStatus(BookingStatus oldStatus){ this.oldStatus = oldStatus; }
    public void setNewStatus(BookingStatus newStatus){ this.newStatus = newStatus; }
    public void setRemarks(String remarks)           { this.remarks = remarks; }
    public void setChangedTime(Long changedTime)     { this.changedTime = changedTime; }
}
