package com.victo.kaivinai.data.dto;

import com.victo.kaivinai.data.dto.enums.UserStatus;
public class Admin {

    private Long       id;
    private String     name;
    private String     email;
    private String     password;
    private String     mobileNo;
    private UserStatus status;
    private Long       createdAt;

    public Admin(Long id, String name, String email,
                 String password, String mobileNo,
                 UserStatus status, Long createdAt) {
        this.id        = id;
        this.name      = name;
        this.email     = email;
        this.password  = password;
        this.mobileNo  = mobileNo;
        this.status    = status;
        this.createdAt = createdAt;
    }

    public Long       getId()        { return id; }
    public String     getName()      { return name; }
    public String     getEmail()     { return email; }
    public String     getPassword()  { return password; }
    public String     getMobileNo()  { return mobileNo; }
    public UserStatus getStatus()    { return status; }
    public Long       getCreatedAt() { return createdAt; }

    public void setId(Long id)               { this.id = id; }
    public void setName(String name)         { this.name = name; }
    public void setEmail(String email)       { this.email = email; }
    public void setPassword(String password) { this.password = password; }
    public void setMobileNo(String mobileNo) { this.mobileNo = mobileNo; }
    public void setStatus(UserStatus status) { this.status = status; }
    public void setCreatedAt(Long createdAt) { this.createdAt = createdAt; }
}
