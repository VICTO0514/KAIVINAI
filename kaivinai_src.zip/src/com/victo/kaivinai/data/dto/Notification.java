package com.victo.kaivinai.data.dto;

import com.victo.kaivinai.data.dto.enums.ReceiverType;

public class Notification {

    public enum NotificationType {
        BookingRequested, BookingAccepted, BookingRejected,
        ProviderOnTheWay, WorkCompleted,
        ReviewReceived, VerificationUpdate
    }

    private Long             id;
    private Long             receiverId;
    private ReceiverType     receiverType;
    private Long             bookingId;
    private String           message;
    private NotificationType type;
    private Boolean          isRead;
    private Long             createdTime;

    public Notification(Long id, Long receiverId, ReceiverType receiverType,
                        Long bookingId, String message,
                        NotificationType type, Boolean isRead,
                        Long createdTime) {
        this.id           = id;
        this.receiverId   = receiverId;
        this.receiverType = receiverType;
        this.bookingId    = bookingId;
        this.message      = message;
        this.type         = type;
        this.isRead       = isRead;
        this.createdTime  = createdTime;
    }

    public Long             getId()           { return id; }
    public Long             getReceiverId()   { return receiverId; }
    public ReceiverType     getReceiverType() { return receiverType; }
    public Long             getBookingId()    { return bookingId; }
    public String           getMessage()      { return message; }
    public NotificationType getType()         { return type; }
    public Boolean          getIsRead()       { return isRead; }
    public Long             getCreatedTime()  { return createdTime; }

    public void setId(Long id)                        { this.id = id; }
    public void setReceiverId(Long receiverId)        { this.receiverId = receiverId; }
    public void setReceiverType(ReceiverType rt)      { this.receiverType = rt; }
    public void setBookingId(Long bookingId)          { this.bookingId = bookingId; }
    public void setMessage(String message)            { this.message = message; }
    public void setType(NotificationType type)        { this.type = type; }
    public void setIsRead(Boolean isRead)             { this.isRead = isRead; }
    public void setCreatedTime(Long createdTime)      { this.createdTime = createdTime; }
}
