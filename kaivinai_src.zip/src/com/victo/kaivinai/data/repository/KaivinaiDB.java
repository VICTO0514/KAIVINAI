package com.victo.kaivinai.data.repository;

public class KaivinaiDB {
}
