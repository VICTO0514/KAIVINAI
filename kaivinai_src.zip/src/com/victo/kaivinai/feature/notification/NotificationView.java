package com.victo.kaivinai.feature.notification;

public class NotificationView {
}
