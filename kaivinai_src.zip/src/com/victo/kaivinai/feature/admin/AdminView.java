package com.victo.kaivinai.feature.admin;

public class AdminView {
}
