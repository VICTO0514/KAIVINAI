package com.victo.kaivinai.feature.category;

public class CategoryModel {
}
