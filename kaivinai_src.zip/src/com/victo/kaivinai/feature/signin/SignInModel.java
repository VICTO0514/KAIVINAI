package com.victo.kaivinai.feature.signin;

public class SignInModel {
}
