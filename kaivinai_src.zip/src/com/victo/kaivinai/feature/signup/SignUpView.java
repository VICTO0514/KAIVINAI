package com.victo.kaivinai.feature.signup;

public class SignUpView {
}
