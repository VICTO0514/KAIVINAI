package com.victo.kaivinai.feature.provider;

public class ProviderModel {
}
