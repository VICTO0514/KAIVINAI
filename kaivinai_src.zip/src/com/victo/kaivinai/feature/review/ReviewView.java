package com.victo.kaivinai.feature.review;

public class ReviewView {
}
