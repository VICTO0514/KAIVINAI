package com.victo.kaivinai.feature.review;

public class ReviewModel {
}
