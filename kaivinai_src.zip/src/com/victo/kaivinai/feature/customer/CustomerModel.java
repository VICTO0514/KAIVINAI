package com.victo.kaivinai.feature.customer;

public class CustomerModel {
}
