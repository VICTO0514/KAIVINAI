package com.victo.kaivinai.feature.customer;

public class CustomerView {
}
