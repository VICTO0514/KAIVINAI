package com.victo.kaivinai.feature.booking;

public class BookingView {
}
